import React from 'react';
import MainLayout from '../layouts/MainLayout';

const Product = () => {
    return <MainLayout>product detail</MainLayout>;
};

export default Product;
