import { Grid } from '@material-ui/core';
import React, { useEffect } from 'react';
import { useProducts } from '../../contexts/ProductsContext';

const Content = () => {
    const { fetchProducts, loading, error, products } = useProducts();

    useEffect(() => {
        fetchProducts();
    }, []);

    useEffect(() => {
        console.log(products);
    }, [products]);

    if (loading) {
        return <h1>...Loading</h1>;
    }

    if (error) {
        return <h1>{error}</h1>;
    }

    return (
        <Grid item md={9}>
            {/* <ProductsList products={products} /> */} // ! Попробуйте через компонент ProductsList
            {products.map((product) => (
                <h1>{product.title}</h1>
            ))}
        </Grid>
    );
};

export default Content;
